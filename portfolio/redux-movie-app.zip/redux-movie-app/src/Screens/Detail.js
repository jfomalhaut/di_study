import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { GetMovieCasts, GetMovieDetail, GetMovieVideo, GetSimilarMovie, addMovieToFavorite, addToFavorite } from '../actions/movieActions'
import ReactPlayer from "react-player";
import { LoadingBox } from '../Components/LoadingBox';
import { Section } from '../styles/DetailStyle';
import { Link } from 'react-router-dom'
import { MdBookmark } from 'react-icons/md';
import { GetActor, GetMovieDetail2 } from '../api';
import { useState } from 'react';
import styled, { css } from 'styled-components';

const Detail = ({ match }) => {
    const [detailInfo, setDetailInfo] = useState({}); // Movie Info
    const [include, setInclude] = useState(false);
    const [actor, setActor] = useState({}); // ActorInfo

    const POSTER_URL = 'https://image.tmdb.org/t/p/original/';
    const PORTRAIT_URL = 'https://image.tmdb.org/t/p/w200';
    const YOUTUBE_URL = "https://www.youtube.com/watch?v=";

    let params = match.params;
    const dispatch = useDispatch();
    const detail = useSelector(state => state.DetailMovie)
    const trailer = useSelector(state => state.MovieVideo)
    const casts = useSelector(state => state.MovieCasts)
    const similar = useSelector(state => state.SimilarMovie)
    const favorites = useSelector(state => state.Favorite);
    // const addFavorite = useSelector(state => state.FavoriteMovie)

    const init = async () => {
        try {
            const movieInfo = await GetMovieDetail2(params.id);
            setDetailInfo(movieInfo.data);
        } catch {
            alert('network error');
        }
    };

    const addMovieToWatchlist = (item) => {
        dispatch(addToFavorite(item.movie));
    };

    const onModal = async (actor_id) => {
        const { data } = await GetActor(actor_id);
        setActor(data);
    };
    const close = () => {
        setActor({});
    };


    // 해당 영화가 즐겨찾기 리스트에 포함 되는지 여부
    useEffect(() => {
        // id만 우선 남기고 해당 영화의 아이디가 포함되어 있는지 여부를 확인한다.
        const flag = (favorites.map(item => item.id).indexOf(params.id * 1) === -1) ? false : true;
        setInclude(flag);
    }, [favorites]);

    useEffect(() => {
        window.scrollTo(0, 0);
        init();
        const fetchAPI = async () => {
            dispatch(GetMovieDetail(params.id))
            dispatch(GetMovieVideo(params.id))
            dispatch(GetMovieCasts(params.id))
            dispatch(GetSimilarMovie(params.id))
        }
        fetchAPI();
    }, [params.id]);
    // let storedMovie = watchlist.find((item) => item.id === detail.id);
    // const watchlistDisabled = storedMovie ? true : false;

    // adult
    // also_known_as
    // biography
    // birthday
    // deathday
    // gender
    // homepage
    // id
    // imdb_id
    // known_for_department
    // name
    // place_of_birth
    // popularity
    // profile_path

    return (
        <Section>
            <Modal active={actor.id > 0 ? true : false}>
                <figure onClick={close} />
                <article>
                    <img src={`${PORTRAIT_URL}${actor.profile_path}`} />
                    <h1>{actor.name}</h1>
                    <p>{actor.birthday}</p>
                </article>
            </Modal>
            {detail.loading ?
                <LoadingBox></LoadingBox>
                :
                <>
                    <img src={POSTER_URL + detail.movie.backdrop_path} className="poster__background" />

                    <div className="contents__container">
                        <button
                            className={`save__btn ${include ? 'active' : ''}`}
                            // disabled={watchlistDisabled}
                            onClick={() => addMovieToWatchlist(detail)}
                        >
                            <MdBookmark style={{ fontSize: "4rem" }} />
                        </button>
                        <div className="contents__subcontainer">
                            <div classname="casts__container">
                                <div className="casts__wrap">
                                    {casts.loading ?
                                        <LoadingBox></LoadingBox>
                                        :
                                        <>
                                            {casts.people.map((cast, index) => {
                                                return (
                                                    <div className="cast__info" key={index}>
                                                        {/* {cast.profile_path ?
                                                            <Link to={"/person/" + cast.id}>
                                                                <img className="profile__pic" src={PORTRAIT_URL + cast.profile_path} />
                                                            </Link>
                                                            : <Link>
                                                                <img className="profile__pic" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxANDQ0NDQ0NDQ0NDQ4PDQ4ODQ8NDQ4NFREWFxYSFRMYHSggGBoxGxUVITEhJSkrLi4uFx8zODMsNygtLjEBCgoKDQ0NDg0NDisZFRkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQUCBAYDB//EADUQAQACAAMFBAcIAwEAAAAAAAABAgMEEQUhMVFxEiJBYTJSgZGxweETM0JicoKh0UOS8BT/xAAVAQEBAAAAAAAAAAAAAAAAAAAAAf/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/APuIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPHMZmmHHetpyjjM+wHsKrF2x6lPbaflDwnauJPqR0r/cgvBRV2piR6s9a/09sPbE/ipH7Z0/iQW41svnsPE3RbSeVt0tkAAAAAAAAAAAAAAAAAAAAAGjtLOfZx2a+naP9Y5gzz+cjCrMRMTeeEcvOVDe02mZtMzM8ZlEzrvnfM8ZnxFQAAAAb2S2jNNK31tTnxtX+2igHU0vFoiYnWJ4TDJSbJzPZt2J9G87vKy7RQAAAAAAAAAAAAAAAAAGN7xWJtPCImZ6OaxsWb2m08bTr08l1ta/ZwZj1pivz+SiAAVAAAAAQkCJ0dNl8Tt0rb1qxPtcyudi4muHNfVtu6T/ANKKsQAAAAAAAAAAAAAAAAAVm3J7tI52mfdH1VC125/j/d8lUqISAAAAACEgCy2JbvXjnWJ90/VWrDYv3lv0T8YBdAIoAAAAAAAAAAAAAAACt23XuUnlbT3x9FOu9sXrGH2Z9KZiax04qRUBCQAABCQAAFlsSO9eeVYj3z9Fattiadm++O1M8Nd/Zjx/kFoAigAAAAAAAAAAAAAAAK7bWFrSL+NZ0npP10UzpM5hzfDvWOMxu68XNgAKgAAAAAAs9iYXetieER2Y6zvn5e9WL7ZVOzgxr+KZt7AbgCKAAAAAAAAAAAAAAAAKLaeVmlpvEdy07vKZ4/NevDO4fbwr1/LrHWN8A5wQlUQJQAkQAkAeuVwJxLxWInTWO1PKvi6SI0iIjhHBp7JwuzhRPjeZn2eH/ebdRQAAAAAAAAAAAAAAAAAAAHOZzB+zxLV8Nda/png8Fntz0sPpb4wrFQAAAAZ4WHN7VrHG06fVg3tjfez+ifjALqlYrEVjhEREdGQIoAAAAAAAAAAAAAAAAAAACo25xw+lvkq1ptzjh9LfJWKgAAhICG/sb72f0W+MNFvbG+9n9E/GAXgCKAAAAAAAAAAAAAAAAAiZ03zugEomdI1ndEcWlmNp0rur358uHvVeazt8XdM6V9WN0e3mDLaGYjFxNY9GsaV8/NqoSqAgBIhID2ymN9niVv4RO/pPF4gOow7xaItWdYnhMMnN5bNXwp7s7vGJ31n2LTL7VpbdeOxPPjVFWAitomNYmJjnE6wkAAAAAAAAAAAGGLi1pGtrRWPMGbDExIrGtpiI5zOiszO1vDDjT81vlCtxMS151tM2nzBaZja0Ruw66/mtuj3K7GzF8T07TPlwj3PIVAAEJAECQAAAAEJAGeFjWpOtLTXpw9yxy+1vDEr+6v8ASrAdNg41bxrS0T8Y6w9HLUtNZ1rMxMeMTpKwy21bRuxI7Uc43W+qKuR5YGYriRrS0TzjxjrD1AAAAARM6b53QxxcSKVm1p0iFFnc7bFnT0aeFefUG7m9qxHdwu9PrTw9nNVYuJN51tM2nzYCokEAkEAkQAkQAkQAkQAkQAkQkAQAkQAyraYnWJmJjhMbpWeU2r4Yv+8R8YVQDqaXi0RMTExPCY3wyc5lM1bCnWN8TxrPCV9l8euJWLV9seMTylFeoAKPa2Y7V+xHo0/m3jLRTe2tpnnMyhUAABCQAAAAAAAACAAAAAAAAAAAAbOQzH2eJE/htut05tYB1Io//dbmIrSAVAAAAAAAAAAAAAAAAAAAAAAAAAAEAA//2Q==" />
                                                            </Link>
                                                        } */}
                                                        <figure onClick={() => onModal(cast.id)}>
                                                            <img className="profile__pic" src={cast.profile_path ? PORTRAIT_URL + cast.profile_path : "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxANDQ0NDQ0NDQ0NDQ4PDQ4ODQ8NDQ4NFREWFxYSFRMYHSggGBoxGxUVITEhJSkrLi4uFx8zODMsNygtLjEBCgoKDQ0NDg0NDisZFRkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQUCBAYDB//EADUQAQACAAMFBAcIAwEAAAAAAAABAgMEEQUhMVFxEiJBYTJSgZGxweETM0JicoKh0UOS8BT/xAAVAQEBAAAAAAAAAAAAAAAAAAAAAf/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/APuIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPHMZmmHHetpyjjM+wHsKrF2x6lPbaflDwnauJPqR0r/cgvBRV2piR6s9a/09sPbE/ipH7Z0/iQW41svnsPE3RbSeVt0tkAAAAAAAAAAAAAAAAAAAAAGjtLOfZx2a+naP9Y5gzz+cjCrMRMTeeEcvOVDe02mZtMzM8ZlEzrvnfM8ZnxFQAAAAb2S2jNNK31tTnxtX+2igHU0vFoiYnWJ4TDJSbJzPZt2J9G87vKy7RQAAAAAAAAAAAAAAAAAGN7xWJtPCImZ6OaxsWb2m08bTr08l1ta/ZwZj1pivz+SiAAVAAAAAQkCJ0dNl8Tt0rb1qxPtcyudi4muHNfVtu6T/ANKKsQAAAAAAAAAAAAAAAAAVm3J7tI52mfdH1VC125/j/d8lUqISAAAAACEgCy2JbvXjnWJ90/VWrDYv3lv0T8YBdAIoAAAAAAAAAAAAAAACt23XuUnlbT3x9FOu9sXrGH2Z9KZiax04qRUBCQAABCQAAFlsSO9eeVYj3z9Fattiadm++O1M8Nd/Zjx/kFoAigAAAAAAAAAAAAAAAK7bWFrSL+NZ0npP10UzpM5hzfDvWOMxu68XNgAKgAAAAAAs9iYXetieER2Y6zvn5e9WL7ZVOzgxr+KZt7AbgCKAAAAAAAAAAAAAAAAKLaeVmlpvEdy07vKZ4/NevDO4fbwr1/LrHWN8A5wQlUQJQAkQAkAeuVwJxLxWInTWO1PKvi6SI0iIjhHBp7JwuzhRPjeZn2eH/ebdRQAAAAAAAAAAAAAAAAAAAHOZzB+zxLV8Nda/png8Fntz0sPpb4wrFQAAAAZ4WHN7VrHG06fVg3tjfez+ifjALqlYrEVjhEREdGQIoAAAAAAAAAAAAAAAAAAACo25xw+lvkq1ptzjh9LfJWKgAAhICG/sb72f0W+MNFvbG+9n9E/GAXgCKAAAAAAAAAAAAAAAAAiZ03zugEomdI1ndEcWlmNp0rur358uHvVeazt8XdM6V9WN0e3mDLaGYjFxNY9GsaV8/NqoSqAgBIhID2ymN9niVv4RO/pPF4gOow7xaItWdYnhMMnN5bNXwp7s7vGJ31n2LTL7VpbdeOxPPjVFWAitomNYmJjnE6wkAAAAAAAAAAAGGLi1pGtrRWPMGbDExIrGtpiI5zOiszO1vDDjT81vlCtxMS151tM2nzBaZja0Ruw66/mtuj3K7GzF8T07TPlwj3PIVAAEJAECQAAAAEJAGeFjWpOtLTXpw9yxy+1vDEr+6v8ASrAdNg41bxrS0T8Y6w9HLUtNZ1rMxMeMTpKwy21bRuxI7Uc43W+qKuR5YGYriRrS0TzjxjrD1AAAAARM6b53QxxcSKVm1p0iFFnc7bFnT0aeFefUG7m9qxHdwu9PrTw9nNVYuJN51tM2nzYCokEAkEAkQAkQAkQAkQAkQAkQkAQAkQAyraYnWJmJjhMbpWeU2r4Yv+8R8YVQDqaXi0RMTExPCY3wyc5lM1bCnWN8TxrPCV9l8euJWLV9seMTylFeoAKPa2Y7V+xHo0/m3jLRTe2tpnnMyhUAABCQAAAAAAAACAAAAAAAAAAAAbOQzH2eJE/htut05tYB1Io//dbmIrSAVAAAAAAAAAAAAAAAAAAAAAAAAAAEAA//2Q=="} />
                                                        </figure>
                                                        <div className="cast__name">
                                                            <h5>{cast.original_name}</h5>
                                                            <h6>({cast.character})</h6>
                                                        </div>


                                                    </div>
                                                )
                                            })}
                                        </>
                                    }
                                </div>
                            </div>
                            <div className="description__container">
                                <h1 style={{ fontSize: "3rem", marginBottom: "1rem" }}>{detail.movie.title}</h1>
                                <div className="genre__wrap" style={{ marginBottom: "1rem" }}>
                                    {detail.movie.genres.map((genre, index) => {
                                        return (
                                            <p className="genre__tag" key={index}>{genre.name}</p>
                                        )
                                    })}
                                </div>
                                <p style={{ marginBottom: "1rem" }}><b>Running Time:</b> {detail.movie.runtime}mins</p>
                                <p style={{ marginBottom: "1rem" }}><b>Released at:</b>{detail.movie.release_date}</p>
                                <b>Overview:</b>
                                <p style={{ marginBottom: "1rem" }}>{detail.movie.overview}</p>
                            </div>
                            {trailer.loading ?
                                <LoadingBox></LoadingBox> :
                                <div className="video__container" >
                                    {/* {trailer.video &&
                                        <ReactPlayer
                                            className="video__player"
                                            url={YOUTUBE_URL + trailer.video.key}
                                            playing
                                            width="100%"

                                        />
                                    } */}
                                </div>
                            }

                        </div>


                    </div>
                    <div className="similarMovie__container">
                        <h3 style={{ marginBottom: "1rem", color: "white" }}>Looking for similar movies with "{detail.movie.title}" ?</h3>
                        <div className="similarMovie__wrap">
                            {similar.loading ?
                                <LoadingBox></LoadingBox> :
                                <>
                                    {similar.data.map((movie, index) => {
                                        return (
                                            <Link to={"/movie/" + movie.id}>
                                                <img key={index} className="movie__poster" src={POSTER_URL + movie.poster_path} alt={movie.title}></img>
                                            </Link>

                                        )
                                    })}
                                </>
                            }
                        </div>
                    </div>
                </>
            }
        </Section>
    )
}

export default Detail

const transform = css`
    transform: translate(-50%, -50%);
`;

const Modal = styled.div`
    position: fixed;
    left: 0; right: 0; top: 0; bottom: 0;
    width: 100vw;
    height: 100vh;
    z-index: ${props => props.active ? 10000 : -1};
    figure {
        position: fixed;
        left: 0; right: 0; top: 0; bottom: 0;
        width: 100vw;
        height: 100vh;
        z-index: 999;
        background: rgba(0, 0, 0, .7);
    }

    article {
        position: fixed;
        width: 500px;
        height: 100vh;
        transition: left .2s;
        left: 50%; top: ${props => props.active ? 50 : 100}%;
        top: 0%;
        left: ${props => props.active ? 0 : -200}%;
        background: #0F2027;  /* fallback for old browsers */
        background: -webkit-linear-gradient(to right, #2C5364, #203A43, #0F2027);  /* Chrome 10-25, Safari 5.1-6 */
        background: linear-gradient(to right, #2C5364, #203A43, #0F2027); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
        background: #485563;  /* fallback for old browsers */
        background: -webkit-linear-gradient(to right, #29323c, #485563);  /* Chrome 10-25, Safari 5.1-6 */
        background: linear-gradient(to right, #29323c, #485563); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
        box-shadow: 0 0 15px rgba(0, 0, 0, .5);
        z-index: 9999;
        ${'' /* ${props => props.active && transform} */}
        color: #fff;
    }
`;