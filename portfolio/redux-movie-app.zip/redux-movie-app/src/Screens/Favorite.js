import React from 'react'

const Favorite = () => {
    return (
        <div>

        </div>
    )
}

export default Favorite
